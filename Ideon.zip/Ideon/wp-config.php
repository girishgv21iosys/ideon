<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'ideon' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', '' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'S8.W,Nfp,JYsrJ-uw5JOMaE(kqBA0n2t+r!3CwFZ/&M^[F?B|a2g94XLbA7t_LO5' );
define( 'SECURE_AUTH_KEY',  'AOh_{(PL*s`u9|nHI,^z,.ych~Q%tZjn)AqbL]Gx524QUpgUH68Ch%(SXsTcmm$:' );
define( 'LOGGED_IN_KEY',    'Lt:B!3jj!k{~;9Fy6Y4|&,m.X?U?Eiq$/C!m+E+3v:4b:PJ7<zbfNTIw5FqB`6>,' );
define( 'NONCE_KEY',        '_P>EUR4FYMMpQb+8_Txp)OK%A(:&v|w PVi{Wm?{@2>>GQc=r[IHERfx:Mi%U_Bp' );
define( 'AUTH_SALT',        'I+aQ`#I}$sSp*tp;?qCSo/m3*YmnNxWjTe9kW`5:n,U0I+Q[g]#,k|Bw<_Xt*~rM' );
define( 'SECURE_AUTH_SALT', 'ofce?I?Vd6.L<3WJ<Ik ?DbDYP(KH!RarXN748=.2a;+G*kSiv>pZH*E|u-%+yOq' );
define( 'LOGGED_IN_SALT',   '=g|#7B;9FFU!01kA}S>R#<](526Hunwb(~:ar,zlQk86W5I-?e3ONTKrFoGq5tdG' );
define( 'NONCE_SALT',       'B2p;_h);2Nz.Vymobvxm,&tlV}UoCGTAeKZ$q42uJ0o{1Gcg]zPsyNgFb~7@4[j$' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define( 'WP_DEBUG', false );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Sets up WordPress vars and included files. */
require_once( ABSPATH . 'wp-settings.php' );
